from pygame import *
from sys import *
init()


def draw_text(screen, text, size, color, x, y):
    main_font = font.SysFont('cambria', size)
    text_surface = main_font.render(text, True, color)
    text_rect = text_surface.get_rect()
    text_rect.topleft = (x, y)
    screen.blit(text_surface, text_rect)

class CutSceneZero:
    
    def __init__(self, player):

        # Variables
        self.name = 'zero'
        self.step = 0
        self.timer = time.get_ticks()
        self.cut_scene_running = True
        self.time = 0

        # Dialogue
        self.text = {
            'one': "Something is happening in the rainforest...",
            'two': "The animals are attacking for no reason and they are very aggressive.",
            'three': "Ducky wants to find out what's going on.",
            'four': "Are you willing to help him get to the bottom of the matter?",
            'move': "MOVE: WASD",
            'volume': "VOLUME: ARROWS",
        }
        self.text_counter = 0

    def update(self):

        pressed = key.get_pressed()
        space = pressed[K_SPACE]
        
        if self.time < 100:
            self.time += 1

        if self.step == 0:
            if int(self.text_counter) < len(self.text['one']):
                self.text_counter += 0.4
            else:
                if space:
                    self.step = 1
                    self.time = 0
                    self.text_counter = 0

        if self.step == 1:
            if int(self.text_counter) < len(self.text['two']):
                self.text_counter += 0.4
            else:
                if space and self.time == 100:
                    self.step = 2
                    self.time = 0
                    self.text_counter = 0
        
        if self.step == 2:
            if int(self.text_counter) < len(self.text['three']):
                self.text_counter += 0.4
            else:
                if space and self.time == 100:
                    self.step = 3
                    self.time = 0
                    self.text_counter = 0

        if self.step == 3:
            if int(self.text_counter) < len(self.text['four']):
                self.text_counter += 0.4
            else:
                if space and self.time == 100:
                    self.cut_scene_running = False

        return self.cut_scene_running

    def draw(self, screen):

        draw_text(
            screen,
            self.text['move'][0:len(self.text['move'])],
            35,
            (236, 157, 83),
            50,
            20
        )

        draw_text(
            screen,
            self.text['volume'][0:len(self.text['volume'])],
            35,
            (236, 157, 83),
            900,
            20
        )
        
        if self.step == 0:
            draw_text(
                screen,
                self.text['one'][0:int(self.text_counter)],
                35,
                (255, 255, 255),
                50,
                650
            )

        if self.step == 1:
            draw_text(
                screen,
                self.text['two'][0:int(self.text_counter)],
                35,
                (255, 255, 255),
                50,
                650
            )
        
        if self.step == 2:
            draw_text(
                screen,
                self.text['three'][0:int(self.text_counter)],
                35,
                (255, 255, 255),
                50,
                650
            )

        if self.step == 3:
            draw_text(
                screen,
                self.text['four'][0:int(self.text_counter)],
                35,
                (255, 255, 255),
                50,
                650
            )

class CutSceneOneStart:
    
    def __init__(self, player):

        # Variables
        self.name = 'one_start'
        self.step = 0
        self.timer = time.get_ticks()
        self.cut_scene_running = True
        self.time = 0

        # Dialogue
        self.text = {
            'one': "Hahaha, a duckling.",
            'two': "You won't last a day in this jungle.",
        }
        self.text_counter = 0

    def update(self):

        pressed = key.get_pressed()
        space = pressed[K_SPACE]
        
        if self.time < 100:
            self.time += 1

        if self.step == 0:
            if int(self.text_counter) < len(self.text['one']):
                self.text_counter += 0.4
            else:
                if space:
                    self.step = 1
                    self.time = 0
                    self.text_counter = 0

        if self.step == 1:
            if int(self.text_counter) < len(self.text['two']):
                self.text_counter += 0.4
            else:
                if space and self.time == 100:
                    self.cut_scene_running = False

        return self.cut_scene_running

    def draw(self, screen):
        
        if self.step == 0:
            draw_text(
                screen,
                self.text['one'][0:int(self.text_counter)],
                35,
                (255, 255, 255),
                50,
                650
            )

        if self.step == 1:
            draw_text(
                screen,
                self.text['two'][0:int(self.text_counter)],
                35,
                (255, 255, 255),
                50,
                650
            )

class CutSceneOneFinal:
    
    def __init__(self, player):

        # Variables
        self.name = 'one_final'
        self.step = 0
        self.timer = time.get_ticks()
        self.cut_scene_running = True
        self.time = 0

        # Dialogue
        self.text = {
            'one': "Ouch, what happened?",
            'two': "Something attacked me in the pond and I lost consciousness.",
            'three': "I'll go rest, good luck on your adventure!"
        }
        self.text_counter = 0

    def update(self):

        pressed = key.get_pressed()
        space = pressed[K_SPACE]
        
        if self.time < 100:
            self.time += 1

        if self.step == 0:
            if int(self.text_counter) < len(self.text['one']):
                self.text_counter += 0.4
            else:
                if space:
                    self.step = 1
                    self.time = 0
                    self.text_counter = 0

        if self.step == 1:
            if int(self.text_counter) < len(self.text['two']):
                self.text_counter += 0.4
            else:
                if space and self.time == 100:
                    self.step = 2
                    self.time = 0
                    self.text_counter = 0

        if self.step == 2:
            if int(self.text_counter) < len(self.text['three']):
                self.text_counter += 0.4
            else:
                if space and self.time == 100:
                    self.cut_scene_running = False

        return self.cut_scene_running

    def draw(self, screen):
        
        if self.step == 0:
            draw_text(
                screen,
                self.text['one'][0:int(self.text_counter)],
                35,
                (255, 255, 255),
                50,
                650
            )

        if self.step == 1:
            draw_text(
                screen,
                self.text['two'][0:int(self.text_counter)],
                35,
                (255, 255, 255),
                50,
                650
            )
        
        if self.step == 2:
            draw_text(
                screen,
                self.text['three'][0:int(self.text_counter)],
                35,
                (255, 255, 255),
                50,
                650
            )

class CutSceneManager:

    def __init__(self, screen):
        self.cut_scenes_complete = []
        self.cut_scene = None
        self.cut_scene_running = False

        # Drawing variables
        self.screen = screen
        self.window_size = 0

    def start_cut_scene(self, cut_scene):
        if cut_scene.name not in self.cut_scenes_complete:
            self.cut_scenes_complete.append(cut_scene.name)
            self.cut_scene = cut_scene
            self.cut_scene_running = True

    def end_cut_scene(self):
        self.cut_scene = None
        self.cut_scene_running = False

    def update(self):

        if self.cut_scene_running:
            if self.window_size < self.screen.get_height()*0.3: self.window_size += 2
            self.cut_scene_running = self.cut_scene.update()
        else:
            self.end_cut_scene()

    def draw(self):
        if self.cut_scene_running:
            # Draw rect generic to all cut scenes
            draw.rect(self.screen, (0, 0, 0, 0), (0, 600, self.screen.get_width(), self.window_size))
            # Draw specific cut scene details
            self.cut_scene.draw(self.screen)